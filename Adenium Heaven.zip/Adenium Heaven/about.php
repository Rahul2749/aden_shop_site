<?php

@include 'config.php';

session_start();

// $user_id = $_SESSION['user_id'];

// if(!isset($user_id)){
//    header('location:login.php');
// }z

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>About</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'header.php'; ?>

<section class="about">

   <div class="row">

      <div class="box">
         <img src="images/obessum1.png" alt="">
         <h3>Why Choose Us?</h3>
         <p>Choose us for your Adenium plant needs for top-quality, expertly nurtured varieties. With a wide selection, easy-to-use website, and dedicated customer support, we ensure you receive healthy, thriving plants every time. Make us your trusted source for Adenium beauty.</p>
         <a href="contact.php" class="btn">contact us</a>
      </div>

      <div class="box">
         <img src="images/obessum2.png" alt="">
         <h3>What We Provide?</h3>
         <p>We provide a vast selection of Adenium plants, carefully nurtured for quality assurance. Our user-friendly website, coupled with exceptional customer support, guarantees a seamless shopping experience. Choose us as your trusted source for healthy, vibrant, and exquisite Adenium specimens.</p>
         <a href="shop.php" class="btn">our shop</a>
      </div>

   </div>

</section>



<?php include 'footer.php'; ?>

<script src="js/script.js"></script>

</body>
</html>