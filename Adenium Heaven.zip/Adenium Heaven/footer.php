<footer class="footer">

   <section class="box-container">

      <div class="box">
         <h3>Quick links</h3>
         <a href="home.php"> <i class="fas fa-angle-right"></i> Home</a>
         <a href="shop.php"> <i class="fas fa-angle-right"></i> Shop</a>
         <a href="about.php"> <i class="fas fa-angle-right"></i> About</a>
         <a href="contact.php"> <i class="fas fa-angle-right"></i> Contact</a>
      </div>

      <div class="box">
         <h3>Extra links</h3>
         <a href="cart.php"> <i class="fas fa-angle-right"></i>Cart</a>
         <a href="wishlist.php"> <i class="fas fa-angle-right"></i> Wishlist</a>
         <a href="login.php"> <i class="fas fa-angle-right"></i> Login</a>
         <a href="register.php"> <i class="fas fa-angle-right"></i> Register</a>
      </div>

      <div class="box">
         <h3>Contact Info</h3>
         <p> <i class="fas fa-phone"></i> +91 77750 77637 </p>
         <p> <i class="fas fa-phone"></i> +91 75881 72328 </p>
         <a href="mailto:adeniumheaven@gmail.com.com?subject=Your%20Subject&body=Your%20Message"> <i class="fas fa-envelope"></i> adeniumheaven@gmail.com</a>
         <a href="https://maps.app.goo.gl/TdyEVVbYwhUqoX9r7"> <i class="fas fa-map-marker-alt"></i> Tumsar,M.S,India - 441912 </a>
      </div>

      <div class="box">
         <h3>Follow Us</h3>
         <a href="https://www.facebook.com/groups/627284325542687/"> <i class="fab fa-facebook-f"></i> Facebook </a>
         <a href="https://wa.link/lyewjf"> <i class="fab fa-whatsapp"></i> Whatsapp </a>
         <a href="https://www.instagram.com/adeniumheaven/"> <i class="fab fa-instagram"></i> Instagram </a>
         <a href="https://youtube.com/@adeniumheaven6370?si=XzohRHFwwoj_mR7T"> <i class="fab fa-youtube"></i> Youtube </a>
      </div>

   </section>

   <p class="credit"> &copy; Copyright @ <?= date('Y'); ?> by <span>Adenium Heaven</span> | All Rights Reserved! </p>

</footer>